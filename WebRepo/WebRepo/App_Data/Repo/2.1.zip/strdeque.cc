#include <iostream>
#include <deque>
#include <map>

//extern "C"
//{
#include "strdeque.h"
//}

namespace
{
    const bool debug = true;
    #ifdef NDEBUG
        debug = false;
    #endif

    using std::string;
    using std::deque;
    using map = std::map<unsigned long, deque<string>>;
    bool is_initialized = false;
    map deque_map;
    unsigned long next_insert_index;

    void initialize()
    {
        if(is_initialized) return;

        map new_map;
        deque<string> const_deque;
        new_map[0] = const_deque;
        deque_map = new_map;
        next_insert_index = 1;
        is_initialized = true;
    }

    void cerr_no_param_function(string function_name)
    {
        if(debug) std::cerr << function_name << "()" << std::endl;
    }

    void cerr_three_param_function(string function_name, unsigned long id, size_t pos,
                                                            const char* value)
    {
        if(debug)
        {
            std::cerr << function_name << "(";
            if(id == 0) std::cerr << "the Empty Deque";
            else std::cerr << id;
            std::cerr << ", " << pos << ", ";
            if(value == nullptr) std::cerr << "NULL" << ")\n";
            else std::cerr << "'" << value << "')\n";
        }
    }

    void cerr_two_param_function(string function_name, unsigned long id1, unsigned long id2)
    {
        if(debug)
        {
            std::cerr << function_name << "(";
            if(id1 == 0) std::cerr << "the Empty Deque";
            else std::cerr << id1;
            std::cerr << ", ";
            if(id2 == 0) std::cerr << "the Empty Deque";
            else std::cerr << id2;
            std::cerr << ")\n";
        }
    }

    void cerr_one_param_function(string function_name, unsigned long id)
    {
        if(debug)
        {
            std::cerr << function_name << "(";
            if(id == 0) std::cerr << "the Empty Deque";
            else std::cerr << id;
            std::cerr << ")\n";
        }
    }

    void cerr_id_message(string function_name, unsigned long id, string message)
    {
        if(debug)
        {
            std::cerr << function_name << ": ";
            if(id == 0) std::cerr << "the Empty Deque";
            else std::cerr << "deque " << id;
            std::cerr << " " << message << std::endl;
        }
    }

    void cerr_two_arg_message(string function_name, unsigned long id,
                                string message1, size_t index, string message2)
    {
        if(debug)
        {
            std::cerr << function_name << ": ";
            if(id == 0) std::cerr << "the Empty Deque";
            else std::cerr << "deque " << id;
            std::cerr << " " << message1 << " " << index << " " << message2 << std::endl;
        }
    }

    void cerr_successful_insert(string function_name, unsigned long id,
                                                    const char* val, size_t pos)
    {
        if(debug)
        {
            std::cerr << function_name << ": deque " << id;
            std::cerr << " - element '" << val << "' inserted at ";
            std::cerr << pos << std::endl;
        }
    }

    void cerr_successful_get(string function_name, unsigned long id,
                                                    size_t pos, const char* val)
    {
        if(debug)
        {
            std::cerr << function_name << ": deque " << id;
            std::cerr << " element at " << pos << " is " << "'" << val << "'\n";
        }
    }
}

unsigned long strdeque_new()
{
    initialize();
    const static string strdeque_new_name = "strdeque_new";
    cerr_no_param_function(strdeque_new_name);

    deque<string> new_deque;
    deque_map[next_insert_index] = new_deque;
    unsigned long deque_id = next_insert_index;
    next_insert_index++;

    cerr_id_message(strdeque_new_name, deque_id, "created");
    return deque_id;
}

void strdeque_delete(unsigned long id)
{
    initialize();
    const static string strdeque_delete_name = "strdeque_delete";
    cerr_one_param_function(strdeque_delete_name, id);

    unsigned long erased_deques = deque_map.erase(id);

    if(debug && erased_deques == 1)
        cerr_id_message(strdeque_delete_name, id, "deleted");
    if(debug && erased_deques == 0)
        cerr_id_message(strdeque_delete_name, id, "does not exist");
}

size_t strdeque_size(unsigned long id)
{
    initialize();
    const static string strdeque_size_name = "strdeque_size";
    cerr_one_param_function(strdeque_size_name, id);

    size_t deque_size;
    unsigned long found_deques = deque_map.count(id);
    if(found_deques == 0) deque_size = 0;
    else deque_size = deque_map[id].size();

    if(debug && found_deques == 1)
        cerr_two_arg_message(strdeque_size_name, id, "constains",
                             deque_size, "elements");
    if(debug && found_deques == 0)
        cerr_id_message(strdeque_size_name, id, "does not exist");

    return deque_size;
}

void strdeque_insert_at(unsigned long id, size_t pos, const char* value)
{
    initialize();
    const static string strdeque_insert_name = "strdeque_insert_at";
    cerr_three_param_function(strdeque_insert_name, id, pos, value);

    if(deque_map.count(id) == 0)
    {
        cerr_id_message(strdeque_insert_name, id, "does not exist");
        return;
    }
    if(value == nullptr)
    {
        cerr_id_message(strdeque_insert_name, id,
                        "- attempt to insert NULL into a deque");
        return;
    }

    string val(value);
    deque<string>& searched_deque = deque_map[id];
    size_t insert_index = pos;
    if(pos > searched_deque.size()) insert_index = searched_deque.size();
    searched_deque.insert(searched_deque.begin() + insert_index, val);

    cerr_successful_insert(strdeque_insert_name, id, value, pos);
}

void strdeque_remove_at(unsigned long id, size_t pos)
{
    initialize();
    const static string strdeque_remove_name = "strdeque_remove_at";
    cerr_two_param_function(strdeque_remove_name, id, pos);

    if(deque_map.count(id) == 0)
    {
        cerr_id_message(strdeque_remove_name, id, "does not exist");
        return;
    }

    deque<string>& searched_deque = deque_map[id];
    if(pos >= searched_deque.size())
    {
        cerr_two_arg_message(strdeque_remove_name, id,
                             "does not contain an element at", pos, "");
        return;
    }

    searched_deque.erase(searched_deque.begin() + pos);
    cerr_two_arg_message(strdeque_remove_name, id, "- element at", pos, "removed");
}

const char* strdeque_get_at(unsigned long id, size_t pos)
{
    initialize();
    const static string strdeque_get_name = "strdeque_get_at";
    cerr_two_param_function(strdeque_get_name, id, pos);

    if(deque_map.count(id) == 0)
    {
        cerr_id_message(strdeque_get_name, id, "does not exist");
        return nullptr;
    }

    deque<string>& searched_deque = deque_map[id];
    if(pos >= searched_deque.size())
    {
        cerr_two_arg_message(strdeque_get_name, id,
                             "does not contain an element at", pos, "");
        return nullptr;
    }

    cerr_successful_get(strdeque_get_name, id, pos, searched_deque[pos].c_str());
    return searched_deque[pos].c_str();
}

void strdeque_clear(unsigned long id)
{
    initialize();
    const static string strdeque_clear_name = "strdeque_clear";
    cerr_one_param_function(strdeque_clear_name, id);

    if(deque_map.count(id) == 0){
        cerr_id_message(strdeque_clear_name, id, "does not exist");
        return;
    }


    deque<string> new_deque;
    deque_map[id] = new_deque;
    cerr_id_message(strdeque_clear_name, id, "cleared");
}

int strdeque_comp(unsigned long int id1, unsigned long id2)
{
    initialize();
    const static string strdeque_comp_name = "strdeque_comp";
    cerr_two_param_function(strdeque_comp_name, id1, id2);
    deque<string> deque1, deque2;

    if(deque_map.count(id1) == 0) deque1 = deque_map[0];
    else deque1 = deque_map[id1];

    if(deque_map.count(id2) == 0) deque2 = deque_map[0];
    else deque2 = deque_map[id2];

    if(deque1 < deque2) return -1;
    if(deque1 > deque2) return 1;
    return 0;
}
