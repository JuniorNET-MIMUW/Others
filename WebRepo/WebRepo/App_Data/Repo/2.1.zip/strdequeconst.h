//
// Created by Marek on 22.10.2016.
//

#ifndef ZADANIE2_STRDEQUECONST_H
#define ZADANIE2_STRDEQUECONST_H

#ifdef __cplusplus
extern "C"
#endif //__cplusplus
unsigned long emptystrdeque();


#endif //ZADANIE2_STRDEQUECONST_H
