//
// Created by Marek on 22.10.2016.
//

#include "strdequeconst.h"

unsigned long emptystrdeque()
{
    return 0L;
}
